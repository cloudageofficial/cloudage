<!DOCTYPE html>
<html lang="en">
<head>
  <title>Daily ride counts | R</title>

   <!-- <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
  -->  <script src="assets/js/codemirrorepl.js" type="text/javascript"></script>
    <script src="assets/js/repl.js" type="text/javascript"></script>
    <script src="assets/js/python.js" type="text/javascript"></script>
    <script src="assets/js/env/editor.js" type="text/javascript"></script>

    <link rel="stylesheet" type="text/css" media="all" href="assets/css/codemirror.css">
    <link rel="stylesheet" type="text/css" media="all" href="assets/css/solarized.css">


  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  	<script src="assets/js/321e8852-skulpt.js" type="text/javascript"></script>
  	<script src="assets/js/script.js" type="text/javascript"></script>
	<script src="assets/js/321e8852-skulpt-stdlib.js" type="text/javascript"></script>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/style.css">

  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
 	
</head>
<body>

<div class="container-fluid ">
	<!-- header -->
	<div class ="row">
		<div class="logo col-md-2">
      		<img src="assets/img/logo.png">
      	</div>
      	<div class="course-outline col-xs-offset-3 col-md-5">
      		<nav aria-label="Page navigation example">
			  <ul class="pagination">
			    <li class="page-item"><a class="page-link" href="#"><i class="fa fa-arrow-left" aria-hidden="true"></i></a></li>
			    <li class="page-item"><a class="page-link course-text" href="#"><i class="fa fa-bars" aria-hidden="true"></i>  Course Outline</a></li>
			    <li class="page-item"><a class="page-link" href="#"><i class="fa fa-arrow-right" aria-hidden="true"></i></a></li>
			  </ul>
			</nav>
      	</div>
      	<div class="head-right-menu ">
      		<nav class="navbar ">
			  <div class="container-fluid">
			    	<ul class="nav navbar-nav">
				      	<li class="active">
				      		<a href="#"><svg height="20" width="20"><circle cx="10" cy="10" r="10"  stroke-width="3" fill="#36d57d" /></svg> </a>
				      	</li>
				        <li><a href="#"><i class="fa fa-bell-o" aria-hidden="true"></i></a></li>
				        <li><a href="#"><i class="fa fa-file-pdf-o" aria-hidden="true"></i></a></li>
				        <li><a href="#"><i class="fa fa-info-circle" aria-hidden="true"></i></a></li>
				    </ul>
			    </div>
			</nav>
      	</div>
	</div>
	<!-- end header -->
	  <div class="row content ">
	  	<!-- left sidebar content -->
	  	<div class="col-sm-5 left-block">
	    	<div class="panel-group" id="accordion">
	    		<!-- upper block -->
			    <div class="panel panel-default">
			      <div class="panel-heading">
			        <h4 class="panel-title">
			          <a data-toggle="collapse" data-parent="#accordion" href="#collapse1"><i class="fa fa-check-square-o" aria-hidden="true"></i> Exercise</a>
			        </h4>
			        <button class="sidebar-toggle" data-onboarding="collapse-panel" type="button" ><i class="fa fa-angle-left" aria-hidden="true"></i></button>
			      </div>
			      <div id="collapse1" class="panel-collapse collapse in">
			        <div class="leftview_content upper_text">
			        	<div class="exercise-head"><h1 class="exercise-title">Daily ride counts</h1>
				        	<div>
				        		<p>A useful way to tabulate and visualize cab rides is by looking at the number of rides according to the calendar day. In this exercise, you'll compute this summary and examine how daily ridership varies by time and the day of week.</p>
								<p>The <code>tx</code> data set is preloaded for you.</p>
							</div>
						</div>
					</div>
			      </div>
			    </div>
			    <!-- end upper block -->
			    <!-- lower block -->
			    <div class="panel panel-default">
				    <div class="panel-heading">
				        <h4 class="panel-title">
				          <a data-toggle="collapse" data-parent="#accordion" href="#collapse1"><i class="fa fa-check-circle-o" aria-hidden="true"></i> Instructions</a>
				        </h4>
				    </div>
				    <div id="collapse1" class="panel-collapse collapse in">
				        <div class="leftview_content lower_text">
				        	<div data-onboarding="instructions" class="left-exercise-instructions exercise-typography">
				        		<div>
				        			<div class="left-exercise-instructions_content">
				        				<ul>
											<li>Create a daily summary, grouping by the date of pickup (<code>pickup_date</code>) and counting the number of rides, calling the new variable <code>n_rides</code>.</li>
											<li>Plot the result using ggplot2's <code>geom_line()</code>, with <code>pickup_date</code> on the x-axis and <code>n_rides</code> on the y-axis.</li>
										</ul>
									</div>
								</div>
								<div class="feedback" tabindex="-1">
									<div style="position: absolute; width: 0px; height: 0px; visibility: hidden; display: none;">
									</div>
										<ul class="feedback-tab-list">
											<div data-tip="true" data-for="tp-hint" currentitem="true" style="display: inline-block;">
												<div class="react-component-tooltip place-right type-dark tooltip top" data-id="tooltip" style="left: 181px; top: 216px;">
													<div class="tooltip-inner">Ctrl+H</div>
												</div>
												<a class="left-exercise-show-hint" data-cy="left-exercise-show-hint" href="javascript:void(0)">
													<i class="fa fa-lightbulb-o" aria-hidden="true"></i>
													<span>Take Hint (-30 XP)</span>
												</a>
											</div>
										</ul>
								</div>
							</div>
						</div>
				    </div>
			    </div>
			    <!-- end lower block -->
			</div>
	    </div>
	    <!-- End left sidebar content -->

	    <!-- Right side content -->
	    <div class="col-sm-6 right-side-block">
	    	<div class="panel-group" id="accordion">
			    <ul class="nav nav-tabs">
    				<li class="active"><a data-toggle="tab" href="#script">Home</a></li>
				   <!--  <li><a data-toggle="tab" href="#menu1">Menu 1</a></li>
				    <li><a data-toggle="tab" href="#menu2">Menu 2</a></li>
				    <li><a data-toggle="tab" href="#menu3">Menu 3</a></li> -->
				</ul>

			<div class="tab-content">
			    <div id="script" class="tab-pane fade in active">
			      	<textarea id="yourcode" cols="80" rows="30">
# Python program to demonstrate
# basic array characteristics
import numpy as np
# Creating array object
arr = np.array( [[ 1, 2, 3],[ 4, 2, 5]] )

# Printing type of arr object
print("Array is of type: ", type(arr))

# Printing array dimensions (axes)
print("No. of dimensions: ", arr.ndim)

# Printing shape of array
print("Shape of array: ", arr.shape)

# Printing size (total number of elements) of array
print("Size of array: ", arr.size)

# Printing type of elements in array
print("Array stores elements of type: ", arr.dtype)							
																										      		
					</textarea>
					<div class="content-buttons">
							<div data-tip="true" data-for="tp-7" style="display: inline-block;" currentitem="true"><div class="react_component_tooltip place-left type-dark tooltip left" data-id="tooltip" style="left: 837px; top: 340px;"><div class="tooltip-inner">Reset To Sample Code</div></div>
							<a style="  " class="exercise-reset dc-btn btn-tertiary btn-squared btn-sm" href="javascript:void(0)">
							<i class="fa fa-refresh" aria-hidden="true"></i>
						</a></div>
						<div data-tip="true" data-for="tp-8" style="display: inline-block;" currentitem="false"><div class="component_tooltip place-top type-dark " data-id="tooltip"></div>
							<button type="button" aria-label="button" class="btn btn-tertiary btn-sm " id="skulpt_run" style="" onClick="runit()"><i class="fa fa-play" aria-hidden="true"></i></button>

						</div>
						<div data-tip="true" data-for="tp-9" style="display: inline-block;" currentitem="false">
							<div class="react_component_tooltip place-top type-dark " data-id="tooltip"></div>
							<button aria-label="button" class="btn btn-tertiary btn-green btn-sm " type="button" data-onboarding="submit-button" data-test-id="execute-code-button" data-cy="submit-button" style=""><span><div class="dc-btn__content"><i class="fa fa-paper-plane" aria-hidden="true"></i></div></span>
							</button>
						</div>
					</div>
					
			    </div>
			    <div id="menu1" class="tab-pane fade">
			      <h3>Menu 1</h3>
			      <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
			    </div>
				<div class="panel panel-default">
					<div class="panel-heading">
					 	<h4 class="panel-title">
						    <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">R Console</a>
						</h4>
					</div>
					<div id="collapse1" class="panel-collapse collapse in">
						<div class="panel-body">
						    <pre id="output" ></pre>
									<!-- If you want turtle graphics include a canvas -->
							<div id="mycanvas"></div>
						</div>
					</div>
				</div>
			</div>
	    </div>
	    <!-- End rightside content -->
	  </div>
</div>


</body>
</html>
