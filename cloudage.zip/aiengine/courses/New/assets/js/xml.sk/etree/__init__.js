var $builtinmodule = function(name) {
  var etree = {};

  return etree;
};
