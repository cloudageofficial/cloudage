var $builtinmodule = function(name) {
  var xml = {};

  return xml;
};
