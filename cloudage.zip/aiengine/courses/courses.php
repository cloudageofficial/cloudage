<!DOCTYPE html>
<!--[if lt IE 7]><html class="no-js lt-ie9 lt-ie8 lt-ie7"><![endif]-->
<!--[if IE 7]><html class="no-js lt-ie9 lt-ie8"><![endif]-->
<!--[if IE 8]><html class="no-js lt-ie9"><![endif]-->
<!--[if gt IE 8]><!--><html class="no-js"><!--<![endif]-->
	<head>
		<meta charset="utf-8">
    <link rel="icon" href="../img/logo.png" type="image/png" sizes="16x16">
		<title>CloudAge - AI Feeds</title>  
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="description" content="">
		<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
		<!-- <link rel="stylesheet" href="css/normalize.css">
		<link rel="stylesheet" href="css/stylesheet.css"> -->

		<!--[if IE 8]><script src="js/es5.js"></script><![endif]-->
		<script src="/cloudage/aiengine/js/jquery.min.js"></script>
		<script src="/cloudage/aiengine/dist/js/standalone/selectize.js"></script>
		<script src="/cloudage/aiengine/js/index.js"></script>
		<!-- template files -->

		<!-- Custom fonts for this template -->
    <link href="/cloudage/aiengine/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

		<!-- Custom styles for this template -->
		<link href="/cloudage/aiengine/css/sb-admin-2.min.css" rel="stylesheet"> 

		<!-- Custom styles for this page -->
		<link href="/cloudage/aiengine/vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet"> 

    <!-- for numpy -->
    <script src="/cloudage/aiengine/courses/assets/js/codemirrorepl.js" type="text/javascript"></script>
    <script src="/cloudage/aiengine/courses/assets/js/repl.js" type="text/javascript"></script>
    <script src="/cloudage/aiengine/courses/assets/js/python.js" type="text/javascript"></script>
    <script src="/cloudage/aiengine/courses/assets/js/env/editor.js" type="text/javascript"></script>

    <link rel="stylesheet" type="text/css" media="all" href="/cloudage/aiengine/courses/assets/css/codemirror.css">
    <link rel="stylesheet" type="text/css" media="all" href="/cloudage/aiengine/courses/assets/css/solarized.css">
    <script src="/cloudage/aiengine/courses/assets/js/321e8852-skulpt.js" type="text/javascript"></script>
    <script src="/cloudage/aiengine/courses/assets/js/script.js" type="text/javascript"></script>
  <script src="/cloudage/aiengine/courses/assets/js/321e8852-skulpt-stdlib.js" type="text/javascript"></script>

 <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>--><!-- 
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"> -->
  <link rel="stylesheet" href="/cloudage/aiengine/courses/assets/css/style.css">

  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	</head>
<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="/cloudage/aiengine/index.php">
        <img src="../img/logo.png" width="70%;">
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item ">
        <a class="nav-link" href="/cloudage/aiengine/index.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>
      
      <!-- AI feeds -->
      <!-- <li class="nav-item">
        <a class="nav-link collapsed" href="/aiengine/staff/ai-feeds.html">
          <i class="fas fa-rss fa-cog"></i>
          <span>AI Feeds</span>
        </a>
      </li> -->
      <!-- End AI feeds --> 
      <!-- AI Data -->
      <!-- <li class="nav-item">
        <a class="nav-link collapsed" href="/aiengine/ai-data.html">
          <i class="fas fa-table fa-cog"></i>
          <span>AI Data</span>
        </a>
      </li> -->
      <!-- End AI Data -->
    
      <!-- Traning -->
      <!-- <li class="nav-item">
        <a class="nav-link collapsed" href="/aiengine/traning.html">
          <i class="fas fa-laptop fa-cog"></i>
          <span>Traning</span>
        </a>
      </li> -->
      <!-- End Traning -->

      <!-- Traning -->
      <li class="nav-item active">
        <a class="nav-link collapsed" href="/cloudage/aiengine/courses/courses.php">
          <i class="fas fa-laptop fa-cog"></i>
          <span>Course</span>
        </a>
      </li>
      <!-- End Traning -->

      <!-- Setting -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="/cloudage/aiengine/settings.php">
          <i class="fas fa-fw fa-cog"></i>
          <span>Settings</span>
        </a>
      </li>
      <!-- End setting -->

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          <!-- Topbar Search -->
          <!-- <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
            <div class="input-group">
              <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
              <div class="input-group-append">
                <button class="btn btn-primary" type="button">
                  <i class="fas fa-search fa-sm"></i>
                </button>
              </div>
            </div>
          </form> -->

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>

            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small">User Name</span>
                <img class="img-profile rounded-circle" src="https://source.unsplash.com/iFSvn82XfGo/60x60">
              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="/aiengine/profile.html">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Profile
                </a>
                <a class="dropdown-item" href="/aiengine/settings.html">
                  <i class="fas fa-fw fa-cog mr-2 text-gray-400"></i>
                  Settings
                </a>
                <a class="dropdown-item" href="/aiengine/change-password.html">
                  <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                  Change Password
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
         
          <!-- DataTales Example -->
          <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h6 class="m-0 font-weight-bold text-primary">Courses</h6>
            </div>
            <div class="card-body">
                <div class="">  
                  <div class="container-fluid ">
  <!-- header -->
  <div class="row">
    <div class="logo col-md-2">
          <img src="assets/img/logo.png">
        </div>
        <div class="course-outline col-xs-offset-3 col-md-5">
          <nav aria-label="Page navigation example">
        <ul class="pagination">
          <li class="page-item"><a class="page-link" href="#"><i class="fa fa-arrow-left" aria-hidden="true"></i></a></li>
          <li class="page-item"><a class="page-link course-text" href="#"><i class="fa fa-bars" aria-hidden="true"></i>  Course Outline</a></li>
          <li class="page-item"><a class="page-link" href="#"><i class="fa fa-arrow-right" aria-hidden="true"></i></a></li>
        </ul>
      </nav>
        </div>
        <div class="head-right-menu ">
          <nav class="navbar ">
        <div class="container-fluid">
            <ul class="nav navbar-nav">
                <li class="active">
                  <a href="#"><svg height="20" width="20"><circle cx="10" cy="10" r="10" stroke-width="3" fill="#36d57d"></circle></svg> </a>
                </li>
                <li><a href="#"><i class="fa fa-bell-o" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-file-pdf-o" aria-hidden="true"></i></a></li>
                <li><a href="#"><i class="fa fa-info-circle" aria-hidden="true"></i></a></li>
            </ul>
          </div>
      </nav>
        </div>
  </div>
  <!-- end header -->
    <div class="row content ">
      <!-- left sidebar content -->
      <div class="col-sm-5 left-block">
        <div class="panel-group" id="accordion">
          <!-- upper block -->
          <div class="panel panel-default">
            <div class="panel-heading">
              <h4 class="panel-title">
                <a data-toggle="collapse" data-parent="#accordion" href="#collapse1"><i class="fa fa-check-square-o" aria-hidden="true"></i> Exercise</a>
              </h4>
              <button class="sidebar-toggle" data-onboarding="collapse-panel" type="button"><i class="fa fa-angle-left" aria-hidden="true"></i></button>
            </div>
            <div id="collapse1" class="panel-collapse collapse in">
              <div class="leftview_content upper_text">
                <div class="exercise-head"><h1 class="exercise-title">Daily ride counts</h1>
                  <div>
                    <p>A useful way to tabulate and visualize cab rides is by looking at the number of rides according to the calendar day. In this exercise, you'll compute this summary and examine how daily ridership varies by time and the day of week.</p>
                <p>The <code>tx</code> data set is preloaded for you.</p>
              </div>
            </div>
          </div>
            </div>
          </div>
          <!-- end upper block -->
          <!-- lower block -->
          <div class="panel panel-default">
            <div class="panel-heading">
                <h4 class="panel-title">
                  <a data-toggle="collapse" data-parent="#accordion" href="#collapse1"><i class="fa fa-check-circle-o" aria-hidden="true"></i> Instructions</a>
                </h4>
            </div>
            <div id="collapse1" class="panel-collapse collapse in">
                <div class="leftview_content lower_text">
                  <div data-onboarding="instructions" class="left-exercise-instructions exercise-typography">
                    <div>
                      <div class="left-exercise-instructions_content">
                        <ul>
                      <li>Create a daily summary, grouping by the date of pickup (<code>pickup_date</code>) and counting the number of rides, calling the new variable <code>n_rides</code>.</li>
                      <li>Plot the result using ggplot2's <code>geom_line()</code>, with <code>pickup_date</code> on the x-axis and <code>n_rides</code> on the y-axis.</li>
                    </ul>
                  </div>
                </div>
                <div class="feedback" tabindex="-1">
                  <div style="position: absolute; width: 0px; height: 0px; visibility: hidden; display: none;">
                  </div>
                    <ul class="feedback-tab-list">
                      <div data-tip="true" data-for="tp-hint" currentitem="true" style="display: inline-block;">
                        <div class="react-component-tooltip place-right type-dark tooltip top" data-id="tooltip" style="left: 181px; top: 216px;">
                          <div class="tooltip-inner">Ctrl+H</div>
                        </div>
                        <a class="left-exercise-show-hint" data-cy="left-exercise-show-hint" href="javascript:void(0)">
                          <i class="fa fa-lightbulb-o" aria-hidden="true"></i>
                          <span>Take Hint (-30 XP)</span>
                        </a>
                      </div>
                    </ul>
                </div>
              </div>
            </div>
            </div>
          </div>
          <!-- end lower block -->
      </div>
      </div>
      <!-- End left sidebar content -->

      <!-- Right side content -->
      <div class="col-sm-6 right-side-block">
        <div class="panel-group" id="accordion">
          <ul class="nav nav-tabs">
            <li class="active"><a data-toggle="tab" href="#script">Home</a></li>
           <!--  <li><a data-toggle="tab" href="#menu1">Menu 1</a></li>
            <li><a data-toggle="tab" href="#menu2">Menu 2</a></li>
            <li><a data-toggle="tab" href="#menu3">Menu 3</a></li> -->
        </ul>

      <div class="tab-content">
          <div id="script" class="tab-pane fade in active">
              <textarea id="yourcode" cols="80" rows="30"># Python program to demonstrate
# basic array characteristics
import numpy as np
# Creating array object
arr = np.array( [[ 1, 2, 3],[ 4, 2, 5]] )

# Printing type of arr object
print("Array is of type: ", type(arr))

# Printing array dimensions (axes)
print("No. of dimensions: ", arr.ndim)

# Printing shape of array
print("Shape of array: ", arr.shape)

# Printing size (total number of elements) of array
print("Size of array: ", arr.size)

# Printing type of elements in array
print("Array stores elements of type: ", arr.dtype)             
                                                              
          </textarea>
          <div class="content-buttons">
              <div data-tip="true" data-for="tp-7" style="display: inline-block;" currentitem="true"><div class="react_component_tooltip place-left type-dark tooltip left" data-id="tooltip" style="left: 837px; top: 340px;"><div class="tooltip-inner">Reset To Sample Code</div></div>
              <a style="  " class="exercise-reset dc-btn btn-tertiary btn-squared btn-sm" href="javascript:void(0)">
              <i class="fa fa-refresh" aria-hidden="true"></i>
            </a></div>
            <div data-tip="true" data-for="tp-8" style="display: inline-block;" currentitem="false"><div class="component_tooltip place-top type-dark " data-id="tooltip"></div>
              <button type="button" aria-label="button" class="btn btn-tertiary btn-sm " id="skulpt_run" style="" onclick="runit()"><i class="fa fa-play" aria-hidden="true"></i></button>

            </div>
            <div data-tip="true" data-for="tp-9" style="display: inline-block;" currentitem="false">
              <div class="react_component_tooltip place-top type-dark " data-id="tooltip"></div>
              <button aria-label="button" class="btn btn-tertiary btn-green btn-sm " type="button" data-onboarding="submit-button" data-test-id="execute-code-button" data-cy="submit-button" style=""><span><div class="dc-btn__content"><i class="fa fa-paper-plane" aria-hidden="true"></i></div></span>
              </button>
            </div>
          </div>
          
          </div>
          <div id="menu1" class="tab-pane fade">
            <h3>Menu 1</h3>
            <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
          </div>
        <div class="panel panel-default">
          <div class="panel-heading">
            <h4 class="panel-title">
                <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">R Console</a>
            </h4>
          </div>
          <div id="collapse1" class="panel-collapse collapse in">
            <div class="panel-body">
                <pre id="output">
</pre>
                  <!-- If you want turtle graphics include a canvas -->
              <div id="mycanvas"></div>
            </div>
          </div>
        </div>
      </div>
      </div>
      <!-- End rightside content -->
    </div>
</div>

                </div>
          </div>
        </div>
          </div>
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->

      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; CloudAge 2019</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->
  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="/aiengine/login.html">Logout</a>
        </div>
      </div>
    </div>
  </div>

  
  <!-- Bootstrap core JavaScript-->
  <script src="/cloudage/aiengine/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- Custom scripts for all pages-->
  <script src="/cloudage/aiengine/js/sb-admin-2.min.js"></script>


</body>  
</html>
<script>
$(document).ready(function(){

        var deptid = $(this).val();

        $.ajax({
            url: 'http://192.168.1.32/sample/sample.json',
            type: 'post',
            data: {depart:deptid},
            dataType: 'json',
            success:function(response){

                var len = response.length;

                $("#select-state").empty();
                for( var i = 0; i<len; i++){
                    var id = response[i]['id'];
                    var name = response[i]['tag_name'];
                    
                    $("#select-state").append("<option value='"+id+"'>"+name+"</option>");

                }
            }
        });
   

});

				var eventHandler = function(name) {

					return function() {

						//console.log(name, arguments);
						$('#log').append('<div><span class="name">' + name + '</span></div>');
					};
				};

  
        
				var $select = $('#select-state').selectize({
          maxItems: 1,
					create          : true,
					onChange        : eventHandler('onChange'),
					onItemAdd       : eventHandler('onItemAdd'),
					onItemRemove    : eventHandler('onItemRemove'),
					onOptionAdd     : eventHandler('onOptionAdd'),
					onOptionRemove  : eventHandler('onOptionRemove'),
					onDropdownOpen  : eventHandler('onDropdownOpen'),
					onDropdownClose : eventHandler('onDropdownClose'),
					onFocus         : eventHandler('onFocus'),
					onBlur          : eventHandler('onBlur'),
					onInitialize    : eventHandler('onInitialize'),
				});
				</script>
<script>  
 $(document).ready(function(){  

      var i=1;  
      $('#add').click(function(){  
           i++;  
           $('#dynamic_field').append('<tr id="row'+i+'"><td><input type="text" name="name[]" placeholder="Enter your Questions" class="form-control name_list" /></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></td></tr>');  
      });  
      $(document).on('click', '.btn_remove', function(){  
           var button_id = $(this).attr("id");   
           $('#row'+button_id+'').remove();  
      });  
      $('#submit').click(function(){            
           $.ajax({  
                url:"name.php",  
                method:"POST",  
                data:$('#add_name').serialize(),  
                success:function(data)  
                {  
                     alert(data);  
                     $('#add_name')[0].reset();  
                }  
           });  
      });  
 });  
 
 
  $(document).ready(function(){  
      var i=1;  
      $('#add1').click(function(){  
           i++;  
           $('#dynamic_field1').append('<tr id="row'+i+'"><td><input type="text" name="name[]" placeholder="Enter your Answer" class="form-control name_list" /></td><td><button type="button" name="remove" id="'+i+'" class="btn btn-danger btn_remove">X</button></td></tr>');  
      });  
      $(document).on('click', '.btn_remove', function(){  
           var button_id = $(this).attr("id1");   
           $('#row'+button_id+'').remove();  
      });  
      $('#submit1').click(function(){            
           $.ajax({  
                url:"name.php",  
                method:"POST",  
                data:$('#add_name1').serialize(),  
                success:function(data)  
                {  
                     alert(data);  
                     $('#add_name1')[0].reset();  
                }  
           });  
      });  
 }); 
 </script>
