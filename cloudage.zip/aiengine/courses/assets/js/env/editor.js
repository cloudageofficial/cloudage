$(document).ready(function () {
	
    var output = $('#edoutput');
    var outf = function (text) {
        output.text(output.text() + text);
    };
    
    var jsoutf = function (text) {
        window.js_output.setValue(text);
    }
    
    var keymap = {
        "Ctrl-Enter" : function (editor) {
            Sk.configure({output: outf, read: builtinRead});
            Sk.canvas = "mycanvas";
            if (editor.getValue().indexOf('turtle') > -1 ) {
                $('#mycanvas').show()
            }
            Sk.pre = "edoutput";
            (Sk.TurtleGraphics || (Sk.TurtleGraphics = {})).target = 'mycanvas';
            try {
                Sk.misceval.asyncToPromise(function() {
                    return Sk.importMainWithBody("<stdin>",false,editor.getValue(),true);
                });
            } catch(e) {
                outf(e.toString() + "\n")
            }
        },
        "Shift-Enter": function (editor) {
            Sk.configure({output: outf, read: builtinRead});
            Sk.canvas = "mycanvas";
            Sk.pre = "edoutput";
            if (editor.getValue().indexOf('turtle') > -1 ) {
                $('#mycanvas').show()
            }
            try {
                Sk.misceval.asyncToPromise(function() {
                    return Sk.importMainWithBody("<stdin>",false,editor.getValue(),true);
                });
            } catch(e) {
                outf(e.toString() + "\n")
            }
        }
    }


    var editor = CodeMirror.fromTextArea(document.getElementById('code'), {
        parserfile: ["parsepython.js"],
        autofocus: true,
        theme: "solarized light",
        //path: "static/env/codemirror/js/",
        styleActiveLine: true,
        lineNumbers: true,
        textWrapping: false,
        indentUnit: 4,
        height: "160px",
        fontSize: "9pt",
        autoMatchParens: true,
        extraKeys: keymap,
        parserConfig: {'pythonVersion': 2, 'strictErrors': true}
    });
    
    var js_output = CodeMirror.fromTextArea(document.getElementById('codeoutput'), {
       parserfile: ["parsejavascript.js"],
        autofocus: false,
        theme: "solarized light",
        //path: "static/env/codemirror/js/",
        lineNumbers: true,
        textWrapping: false,
        indentUnit: 4,
        height: "160px",
        fontSize: "9pt",
        autoMatchParens: true,
        extraKeys: keymap,
    });    
    
    window.code_editor = editor;
    window.js_output = js_output;
	window.jsoutf = jsoutf;
    window.outf = outf;
    window.builtinRead = builtinRead;

    $("#skulpt_run").click(function (e) { keymap["Ctrl-Enter"](editor)} );

    $("#toggledocs").click(function (e) {
        $("#quickdocs").toggle();
    });

    

    $('#clearoutput').click(function (e) {
        $('#edoutput').text('');
        $('#mycanvas').hide();
    });

//upgrate
function builtinRead(x) {
    if (Sk.builtinFiles !== undefined && Sk.builtinFiles["files"][x] !== undefined) {
        return Sk.builtinFiles["files"][x];
    }
    if (Sk.externalLibraries[x]) {
        var externalLibraryInfo = Sk.externalLibraries[x];
        return Sk.misceval.promiseToSuspension(
            new Promise(function(resolve, reject) {
                // get the main skulpt extenstion
                var request = new XMLHttpRequest();
                request.open("GET", externalLibraryInfo.path);
                request.onload = function() {
                    if (request.status === 200) {
                        resolve(request.responseText);
                    } else {
                        reject("File not found: '" + x + "'");
                    }
                };
                request.onerror = function() {
                    reject("File not found: '" + x + "'");
                }
                request.send();
            }).then(function (code) {
                if (!code) {
                    throw new Sk.builtin.ImportError("Failed to load remote module '" + name + "'");
                }
                var promise;
                function mapUrlToPromise(path) {
                    return new Promise(function(resolve, reject) {
                        scriptElement = document.createElement("script");
                        scriptElement.type = "text/javascript";
                        scriptElement.src = path;
                        scriptElement.async = true
                        scriptElement.onload = function() {
                            resolve(true);
                        }
                        document.body.appendChild(scriptElement);
                    });
                }
                if (externalLibraryInfo.loadDepsSynchronously) {
                   promise = (externalLibraryInfo.dependencies || []).reduce((p, url) => {
					   return  p.then(() => mapUrlToPromise(url));
                    }, 
					Promise.resolve()); // initial
                } else {
                    promise = Promise.all((externalLibraryInfo.dependencies || []).map(mapUrlToPromise));
                }
                return promise.then(function() {
                    return code;
                }).catch(function() {
                    throw new Sk.builtin.ImportError("Failed to load dependencies required for " + name);
                });
            })
        );
    }
    throw "File not found '" + x + "'";
 }

Sk.externalLibraries = {
	'matplotlib' : {path : 'matplotlib/__init__.js'},
'matplotlib.pyplot' : {path : 'matplotlib/pyplot/__init__.js',dependencies : ['deps/d3.min.js','deps/jquery.js'],loadDepsSynchronously: true},
'numpy' : {path : 'numpy/__init__.js',dependencies : ['deps/math.js'],loadDepsSynchronously: true},
'turtle' : {path : 'turtle/__init__.js'},
'pygal' : {path : 'pygal/__init__.js',dependencies : ['https://cdnjs.cloudflare.com/ajax/libs/highcharts/6.0.2/highcharts.js',
'https://cdnjs.cloudflare.com/ajax/libs/highcharts/6.0.2/js/highcharts-more.js'],loadDepsSynchronously: true},
'./processing.sk/__init__.js' : {path : 'processing.sk/skulpt_module/__init__.js'},
'./xml.sk/__init__.js' : { path : '/xml.sk/__init__.js'},
  './xml.sk/etree/__init__.js' : {path : 'xml.sk/etree/__init__.js'},
  './xml.sk/etree/ElementTree.js' : {path : 'xml.sk/etree/ElementTree.js'}
 };
Sk.domOutput = function(html) {
  console.log(html);//-->here get the div tag with no content
  //return $('body').append(html).children().last();
  return $('#mycanvas').append(html).children().last();
};


   /* function builtinRead(x) {
        if (Sk.builtinFiles === undefined || Sk.builtinFiles["files"][x] === undefined)
            throw "File not found: '" + x + "'";
        return Sk.builtinFiles["files"][x];
    }*/

    editor.focus();
	
});
