// output functions are configurable.  This one just appends some text
// to a pre element.
function outf(text) {
    var mypre = document.getElementById("output");
    mypre.innerHTML = mypre.innerHTML + text;
}
function builtinRead(x) {
    if (Sk.builtinFiles !== undefined && Sk.builtinFiles["files"][x] !== undefined) {
        return Sk.builtinFiles["files"][x];
    }
    if (Sk.externalLibraries[x]) {
        var externalLibraryInfo = Sk.externalLibraries[x];
        return Sk.misceval.promiseToSuspension(
            new Promise(function(resolve, reject) {
                // get the main skulpt extenstion
                var request = new XMLHttpRequest();
                request.open("GET", externalLibraryInfo.path);
                request.onload = function() {
                    if (request.status === 200) {
                        resolve(request.responseText);
                    } else {
                        reject("File not found: '" + x + "'");
                    }
                };
                request.onerror = function() {
                    reject("File not found: '" + x + "'");
                }
                request.send();
            }).then(function (code) {
                if (!code) {
                    throw new Sk.builtin.ImportError("Failed to load remote module '" + name + "'");
                }
                var promise;
                function mapUrlToPromise(path) {
                    return new Promise(function(resolve, reject) {
                        scriptElement = document.createElement("script");
                        scriptElement.type = "text/javascript";
                        scriptElement.src = path;
                        scriptElement.async = true
                        scriptElement.onload = function() {
                            resolve(true);
                        }
                        document.body.appendChild(scriptElement);
                    });
                }
                if (externalLibraryInfo.loadDepsSynchronously) {
                   promise = (externalLibraryInfo.dependencies || []).reduce((p, url) => {
					   return  p.then(() => mapUrlToPromise(url));
                    }, 
					Promise.resolve()); // initial
                } else {
                    promise = Promise.all((externalLibraryInfo.dependencies || []).map(mapUrlToPromise));
                }
                return promise.then(function() {
                    return code;
                }).catch(function() {
                    throw new Sk.builtin.ImportError("Failed to load dependencies required for " + name);
                });
            })
        );
    }
    throw "File not found '" + x + "'";
 }
// Here's everything you need to run a python program in skulpt
// grab the code from your textarea
// get a reference to your pre element for output
// configure the output function
// call Sk.importMainWithBody()
function runit() {
   var prog = document.getElementById("yourcode").value;
   var mypre = document.getElementById("output");
   mypre.innerHTML = '';
   Sk.pre = "output";
   Sk.configure({output:outf, read:builtinRead});
   var myPromise = Sk.misceval.asyncToPromise(function() {
       return Sk.importMainWithBody("<stdin>", false, prog, true);
   });
   myPromise.then(function(mod) {
       console.log('success');
   },
       function(err) {
       console.log(err.toString());
   });
}
Sk.externalLibraries = {
  './numpy/__init__.js' : {
    path : '__init__.js',
    dependencies : [
        'math.js'
    ],
    loadDepsSynchronously: true
  }
};
Sk.domOutput = function(html) {
  console.log(html);//-->here get the div tag with no content
  //return $('body').append(html).children().last();
  return $('#mycanvas').append(html).children().last();
};
$(function (){
  runit()
})