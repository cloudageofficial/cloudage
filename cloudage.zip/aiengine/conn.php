<?php 
 
// $servername = "localhost";
// $username = "root";
// $password = "";
// $dbname = "cloudage";
 
// // crearte connection
// $connect = new Mysqli($servername, $username, $password, $dbname);
 
// // check connection
// if($connect->connect_error) {
//     die("Connection Failed : " . $connect->error);
// } else {
//      //echo "Successfully Connected";   
// }
 

 session_start();

	// variable declaration
	$username = "";
	$email    = "";
	$errors = array(); 
	$_SESSION['success'] = "";

	// connect to database
	$db = mysqli_connect('localhost', 'root', '', 'cloudage');
// check connection
if($db->connect_error) {
    die("Connection Failed : " . $connect->error);
} else {
    // echo "Successfully Connected";   
}
 