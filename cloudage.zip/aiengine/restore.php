<?php
$target_path = "uploads/restore-";

$target_path = $target_path.basename( $_FILES['restore-uploadedfile']['name']); 

if(move_uploaded_file($_FILES['restore-uploadedfile']['tmp_name'], $target_path)) {
    echo "The file ".  basename( $_FILES['restore-uploadedfile']['name']). 
    " has been restore";
} else{
    echo "There was an error uploading the file, please try again!";
}
?>