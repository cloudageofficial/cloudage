

<div class="container mt-4">
<a href="http://localhost/cloudage/CA_WebSite?source=facebook" data-target="#video_modal" data-toggle="modal" target="_blank" class="btn btn-raised btn-default col-sm-3" >Facebook</a>

<a href="http://localhost/cloudage/CA_WebSite?source=twitter" data-target="#video_modal" data-toggle="modal" target="_blank" class="btn btn-raised btn-default col-sm-3" >Twitter</a>


<a href="/cloudage/CA_WebSite?source=linkedin" target="_blank" class="btn btn-raised btn-default col-sm-3" >Linkedin</a>


<a href="/cloudage/CA_WebSite?source=google" target="_blank" class="btn btn-raised btn-default col-sm-3" >Google Search</a>

<a href="/cloudage/CA_WebSite?source=whatsapp" target="_blank" class="btn btn-raised btn-default col-sm-3" >Whatsapp</a>

<a href="/cloudage/CA_WebSite?source=university" target="_blank" class="btn btn-raised btn-default col-sm-3" >University</a>

<a href="/cloudage/CA_WebSite?source=itpark" target="_blank" class="btn btn-raised btn-default col-sm-3">I.T Park</a>

</div>