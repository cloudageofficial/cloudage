<?php include('header.php');?>
      <div class="ms-hero-page ms-hero-img-keyboard ms-hero-bg-primary mb-6">
        <div class="container">
          <div class="text-center">
            
            <h1 class="no-m ms-site-title color-white center-block ms-site-title-lg mt-2 animated zoomInDown animation-delay-5">Amazon Web Service.(AWS)</h1>
            <p class="lead lead-lg color-white text-center center-block mt-2 mw-800 fw-300 animated fadeInUp animation-delay-7">
           <!-- <span class="colorStar">tricks</span> and
              <span class="colorStar">discounts</span>.</p> -->
          </div>
        </div>
      </div>
      <div class="container"><p>
Whether you're looking for compute power, database storage, content delivery, or other functionality, AWS has the services to help you build sophisticated applications with increased flexibility, scalability and reliability.

</p></div>
      <div class="container">
        
        <div class="row">
          <div class="col-lg-12">
            <h1>Train and deploy models fast</h1>
            <article class="card mb-4 wow materialUp animation-delay-5">
              <figure class="ms-thumbnail ms-thumbnail-diagonal">
                <img src="assets/img/aw.png" alt="" class="img-fluid">
                <figcaption class="ms-thumbnail-caption text-center">
                  <div class="ms-thumbnail-caption-content">
                    <h3 class="ms-thumbnail-caption-title">AWS</h3>
                    <p></p>
                    <div class="mt-2">
                      <a href="javascript:void(0)" class="btn-circle btn-circle-raised btn-circle-sm mr-1 btn-circle-white color-danger">
                        <i class="zmdi zmdi-favorite"></i>
                      </a>
                      <a href="javascript:void(0)" class="btn-circle btn-circle-raised btn-circle-sm ml-1 mr-1 btn-circle-white color-warning">
                        <i class="zmdi zmdi-star"></i>
                      </a>
                      <a href="javascript:void(0)" class="btn-circle btn-circle-raised btn-circle-sm ml-1 btn-circle-white color-success">
                        <i class="zmdi zmdi-share"></i>
                      </a>
                    </div>
                  </div>
                </figcaption>
              </figure>

              <div class="card-body">
                <h2>
                  <a href=javascript:void(0)>AWS</a>
                </h2>
                <p>Amazon Web Services is a subsidiary of Amazon.com that provides on-demand cloud computing platforms to individuals, companies and governments, on a paid subscription basis. The technology allows subscribers to have at their disposal a virtual cluster of computers, available all the time, through the Internet



</p>
                
                <div class="row">
                  <!-- <div class="col-md-6">
                    <div class="mt-1">
                      <a href="javascript:void(0)" class="ms-tag ms-tag-info">Design</a>
                      <a href="javascript:void(0)" class="ms-tag ms-tag-danger">Productivity</a>
                      <a href="javascript:void(0)" class="ms-tag ms-tag-royal">Resources</a>
                    </div>
                  </div> -->
                  <div class="col-md-6">
                    <a href="javascript:void(0)" class="btn btn-primary btn-raised btn-block animate-icon">Read more
                      <i class="ml-1 no-mr zmdi zmdi-long-arrow-right"></i>
                    </a>
                  </div>
                </div>
              </div>
            </article>
            <article class="card mb-4 wow materialUp animation-delay-5">
              <figure class="ms-thumbnail ms-thumbnail-diagonal">
                <!-- <img src="assets/img/demo/post2.jpg" alt="" class="img-fluid"> -->
                <figcaption class="ms-thumbnail-caption text-center">
                  <div class="ms-thumbnail-caption-content">
                    <h3 class="ms-thumbnail-caption-title">AWS</h3>
                    <p>AWS</p>
                    <div class="mt-2">
                      <a href="javascript:void(0)" class="btn-circle btn-circle-raised btn-circle-sm mr-1 btn-circle-white color-danger">
                        <i class="zmdi zmdi-favorite"></i>
                      </a>
                      <a href="javascript:void(0)" class="btn-circle btn-circle-raised btn-circle-sm ml-1 mr-1 btn-circle-white color-warning">
                        <i class="zmdi zmdi-star"></i>
                      </a>
                      <a href="javascript:void(0)" class="btn-circle btn-circle-raised btn-circle-sm ml-1 btn-circle-white color-success">
                        <i class="zmdi zmdi-share"></i>
                      </a>
                    </div>
                  </div>
                </figcaption>
              </figure>
              <div class="card-body">
                <h2>
                  <a href=javascript:void(0)>Why AWS?</a>
                </h2>
                <h3>Machine Learning for everyone</h3>
                <p>Whether you are a data scientist, ML researcher, or developer, GCP offers machine learning services and tools tailored to meet your needs and level of expertise. </p>
                <p>Increase speed and agility
In a cloud computing environment, new IT resources are only ever a click away, which means you reduce the time it takes to make those resources available to your developers from weeks to just minutes. This results in a dramatic increase in agility for the organization, since the cost and time it takes to experiment and develop is significantly lower.,
Stop spending money on running and maintaining data centers,Go global in minutes etc.</p>
                <div class="row">
                  <!-- <div class="col-md-6">
                    <div class="mt-1">
                      <a href="javascript:void(0)" class="ms-tag ms-tag-info">Design</a>
                      <a href="javascript:void(0)" class="ms-tag ms-tag-success">Multimedia</a>
                      <a href="javascript:void(0)" class="ms-tag ms-tag-warning">Graphics</a>
                    </div>
                  </div> -->
                  <div class="col-md-6">
                    <a href="javascript:void(0)" class="btn btn-primary btn-raised btn-block animate-icon">Read more
                      <i class="ml-1 no-mr zmdi zmdi-long-arrow-right"></i>
                    </a>
                  </div>
                </div>
              </div>
            </article>
          
          </div>
         
        </div>
      </div>
      <!-- container -->
      <?php include('footer.php');?>