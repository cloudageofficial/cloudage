<?php
include('header.php');
?>
<h3>
	H2O.ai is a Leader in the Gartner Magic Quadrant for Data Science & Machine Learning Platforms
</h3>

H2O is recognized as a Leader positioned furthest for its Completeness of Vision
We are thrilled to be named a Leader among the 16 vendors included in Gartner’s 2018 Magic Quadrant for Data Science Platforms. As a Leader we believe that we are best positioned to help accelerate AI adoption in Enterprise.

Download the full report to see:

A snapshot of the data science & machine learning platform market
An analysis of 16 vendors in the space
What makes H2O.ai an industry leader

<?php include('footer.php');?>